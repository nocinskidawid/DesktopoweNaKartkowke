﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Pracownik oPracownik = null;

        public MainWindow()
        {
            InitializeComponent();

            oPracownik = new Pracownik("Jan", "Kowalski", "12-123" ,"Katowice", "Jankiewskiego", 8, 1);
            grid.DataContext = oPracownik;          
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Dodano nowego pracownika: \nImie: " + oPracownik.Imie + "\nNazwisko: " + oPracownik.Nazwisko + "\n\nDane adresowe:\nMiejscowosc: "+oPracownik.Miejscowosc+"\nKod Pocztowy: "+oPracownik.kodPocztowy+"\nUlica: "+oPracownik.Ulica+" "+oPracownik.nrBudynku+"/"+oPracownik.nrLokalu);
        }
    }
}