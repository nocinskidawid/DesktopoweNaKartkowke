﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    internal class Pracownik
    {
        public Pracownik(string imie, string nazwisko, string miejscowosc, string kod_pocztowy, string ulica, int nr_budynku, int nr_lokalu)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Miejscowosc = miejscowosc;
            kodPocztowy = kod_pocztowy;
            Ulica = ulica;
            nrLokalu = nr_lokalu;
            nrBudynku = nr_budynku;
        }

    public string Imie { get; set; }

    public string Nazwisko { get; set; }

    public string Miejscowosc { get; set; }
    
    public string kodPocztowy { get; set; }

    public string Ulica { get; set; }

    public int nrLokalu { get; set; }

    public int nrBudynku { get; set; }
    }
}
