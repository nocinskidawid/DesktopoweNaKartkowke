﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ListaStanowisk.ItemsSource = new ObservableCollection<string>()
            {

                "Prezes",
                "wiceprezes",
                "Kierownik",
                "robol",
                "ukrainiec"

            };

            ListaPlci.ItemsSource = new ObservableCollection<string>()
            {
                "Mezczyzna",
                "Kobieta",
            };
        }
    }
}